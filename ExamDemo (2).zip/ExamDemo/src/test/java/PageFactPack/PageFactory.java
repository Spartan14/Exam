package PageFactPack;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PageFactory {
	static WebDriver driver;
	public static void openbrowser(String url) {
		System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get(url);
		System.out.println("Browser opened");
		driver.manage().window().maximize();
		
	}
	
	public static void Alert(String Expected)
	{
		 String expected=Expected;
		  String actual=driver.switchTo().alert().getText(); 
		  Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
	}
	public static void SendValue(By locator ,String val) {
		WebElement e=driver.findElement(locator);
		System.out.println("The text "+val +"is entered. ");
		e.sendKeys(val);
	}

	public static void clickmethod(By locatorforClick) throws InterruptedException {
		driver.findElement(locatorforClick).click();
		System.out.println(locatorforClick +"is clicked.");
		Thread.sleep(3000);
		}
	public static void close() {
		System.out.println("Closing the browser");
		driver.close();
	}
	public static void select(By locator,String val)
	{
		WebElement el=driver.findElement(locator);	
		Select dd=new Select(el); 
		dd.selectByVisibleText(val);
		System.out.println("The value: "+val +" is selected from the dropdown");
	}
	
}
