package stepdefinition;

import Demo.ElementLocators;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class StepDefinition {
	@Given("^The user is on hotel booking login page$")
	public void the_user_is_on_hotel_booking_login_page() throws Throwable {
	   
		 PageFactPack.PageFactory.openbrowser("file:///C:/Users/sonasain/Desktop/sonalisaini/Hotel%20booking%20case%20study/login.html");
	}
	@When("^user successfully login$")
	public void user_successfully_login() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.Username, "capgemini");
		PageFactPack.PageFactory.SendValue(ElementLocators.Password, "capg1234");
		PageFactPack.PageFactory.clickmethod(ElementLocators.login);
	}
	@When("^Enter the invalid Name$")
	public void enter_the_invalid_Name() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.FirstName, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Confirm_Booking);
	}

	@Then("^Accept the Alert$")
	public void accept_the_Alert() throws Throwable {
		PageFactPack.PageFactory.Alert("Please fill the First Name");  
	}

	@When("^Enter the valid Name$")
	public void enter_the_valid_Name() throws Throwable {
	   
		PageFactPack.PageFactory.SendValue(ElementLocators.FirstName, "Raju");
	}
	@When("^Enter the invalid Lastname$")
	public void enter_the_invalid_Lastname() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.LastName, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Confirm_Booking);
	  
	}
	@Then("^Accepts the Alert for last name$")
	public void accepts_the_Alert_for_last_name() throws Throwable {
		PageFactPack.PageFactory.Alert("Please fill the Last Name");  
	}


	@When("^Enters the Last Name$")
	public void enters_the_Last_Name() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.LastName, "saini");

	    
	}

	@When("^Enters the Email$")
	public void enters_the_Email() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.Email, "tola234@gmail.com");
	}

	@When("^Enters the Mobile_no$")
	public void enters_the_Mobile_no() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.Phone, "7954788959");
	    
	}

	@When("^Enters the Address$")
	public void enters_the_Address() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.Address, "Siruseri");
	    
	}

	@When("^Selects City$")
	public void selects_City() throws Throwable {
		PageFactPack.PageFactory.select(ElementLocators.City, "Chennai");
	    
	}

	@When("^Selects State$")
	public void selects_State() throws Throwable {
		PageFactPack.PageFactory.select(ElementLocators.State, "Tamilnadu");
	    
	}

	@When("^Selects Number of guest staying$")
	public void selects_Number_of_guest_staying() throws Throwable {
		PageFactPack.PageFactory.select(ElementLocators.Number_of_guest_staying, "5");
	    
	}



	@When("^Enters Card holder name$")
	public void enters_Card_holder_name() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.Card_Holder_Name, "Shakti");
	    
	}

	@When("^Enters Debit card number$")
	public void enters_Debit_card_number() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.Debit_Card_Number, "Shakti");

	    
	}

	@When("^Enters CVV$")
	public void enters_CVV() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.CVV, "235");
	    
	}

	@When("^Enters Expiration Month$")
	public void enters_Expiration_Month() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.Expiration_Month, "5");
	    
	}

	@When("^Enters Expiration Year$")
	public void enters_Expiration_Year() throws Throwable {
		PageFactPack.PageFactory.SendValue(ElementLocators.Expiration_Year, "1998");
	    
	}

	@When("^clicks on Confirm Booking$")
	public void clicks_on_Confirm_Booking() throws Throwable {
		PageFactPack.PageFactory.clickmethod(ElementLocators.Confirm_Booking);

	    
	}

	@Then("^user is successfully booked$")
	public void user_is_successfully_booked() throws Throwable {
	   
		PageFactPack.PageFactory.close();

	}



}
